-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jun 07, 2012 at 05:15 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_boto`
--
CREATE DATABASE `db_boto` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_boto`;

-- --------------------------------------------------------

--
-- Table structure for table `contactinfo`
--

CREATE TABLE `contactinfo` (
  `id` int(11) NOT NULL auto_increment,
  `infoBoto` text NOT NULL,
  `infoBi` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `contactinfo`
--

INSERT INTO `contactinfo` (`id`, `infoBoto`, `infoBi`) VALUES
(1, 'Le Mas des Oliviers<br />\r\nChemin de la Cubelle<br /> \r\n30740 Le Cailar<br />\r\nFrance<br/>\r\nmail address: barralosteo@orange.fr\r\n', '11211 Prosperity Farms Road, Suite D325<br />\r\nPalm Beach Gardens, Florida 33410<br />\r\nUSA<br />\r\n561-624-3761<br />\r\n<a href=\\"mailto:info@barralinstitute.com\\">info@barralinstitute.com</a>\r\n<br />\r\n<a href=\\"http://www.barralinstitute.com/\\" target=\\"_blank\\">www.barralinstitute.com</a>');

-- --------------------------------------------------------

--
-- Table structure for table `seminars`
--

CREATE TABLE `seminars` (
  `id` int(11) NOT NULL auto_increment,
  `country` text NOT NULL,
  `city` text NOT NULL,
  `seminarName` text NOT NULL,
  `seminarDate` text NOT NULL,
  `teacher` text NOT NULL,
  `sponsorBusName` text NOT NULL,
  `sponsorName` text NOT NULL,
  `address` text NOT NULL,
  `phone` text NOT NULL,
  `email` text NOT NULL,
  `publishFlag` tinyint(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `seminars`
--

INSERT INTO `seminars` (`id`, `country`, `city`, `seminarName`, `seminarDate`, `teacher`, `sponsorBusName`, `sponsorName`, `address`, `phone`, `email`, `publishFlag`) VALUES
(1, 'Argentina - Argentine (Buenos Aires)', 'Buenos Aires', '', '7-8-9 septembre 2014<br />\r\nSpine<br />\r\n<br />\r\n11-12-13 septembre 2014<br />\r\nMbre sup', 'Jean Pierre Barral, DO, MRO(F)', '', 'Gonzalo Martin Mallo', '507 Rodriguez PeÃ±a<br />\r\n2nde floor<br />\r\nBuenos Aires, Argentina 1022<br />', '', 'gonzamallo@gmail.com', 1),
(2, 'France (Limonest)', 'Limonest', '', '28-29-30 mars 2012: diagnostic thermique manuelle, libÃ©ration\r\nViscÃ©ro-Ã©motionnelle<br /><br />\r\n3-4-5 octobre 2012: synthÃ¨se<br /><br />\r\n16-17-18 janvier 2013: uro-gÃ©nital avancÃ©', 'Jean Pierre Barral, DO, MRO(F)', 'AT Still Lyon (ATSA)', '', '280 allÃ©e des HÃªtres<br />\r\nLimonest, France 69760 ', '+33478432006', 'atsa@wanadoo.fr', 1),
(3, 'France (Camargue)', 'Camargue', '', '12-13-14 avril 2012<br />\r\nNouvelle approche manipulative du membre infÃ©rieur<br /><br />\r\n20-21-22 fevrier 2013<br />\r\nNouvelle approche manipulative du membre supÃ©rieur , Ã  confirmer', 'Jean Pierre Barral, DO, MRO(F)', '', 'BOTO et SOORF', 'Seminar Location:<br />\r\nLes Jasses de Camargue<br />\r\nroute d\\''Aimargues<br />\r\n30660 Gallargues-Le-Monteux, France<br />\r\nwww.jasses-de-camargue.com', '', '', 1),
(4, 'Finland - Finlande (Helsinki)', 'Helsinki', '', '30 avril-1-2-3 mai 2012<br />\r\nVisceral Manipulation: Thorax â€“ cardiovascular and pulmonary considerations<br />\r\n<br />\r\n23-24-25-26 oct 2012<br />\r\nNeural Manipulation: Treatment of trauma and whiplash in the body', 'Jean Pierre Barral, DO, MRO(F)', 'www.metropolia.fi', 'Elina Kaukonen and Sandra Rinne', '', '', 'elina.kaukonen@metropolia.fi & sandra.rinne@metropolia.fi', 1),
(5, 'Denmark - Danemark', '', '', '16-17-18 mai 2012<br />\r\n18-19-20 sept 2013<br />\r\n23-24-25 septembre 2014', 'Jean Pierre Barral, DO, MRO(F)', '', 'Kare Nielsen', '', '', 'kaare@osteopater.dk', 1),
(6, 'Switzerland - Suisse (Fribourg)', 'Fribourg', 'ViscÃ©ral avancÃ©', '6-7-8 juin 2012', 'Jean Pierre Barral, DO, MRO(F)', '', 'Centre de formation FSO-SVO', 'Rte des Arsenaux 9<br />\r\nCH-1700 Fribourg<br />\r\nSuisse', '+41-26-322-05-10', 'suzi.aebischer@svo-fso.ch', 1),
(7, 'Austria - Autriche', '', '', '12-13-14 dec 2012<br />\r\ncolonne-bassin<br /><br />\r\n9-10-11 octobre 2013<br />\r\nmembre superieur<br /><br />\r\n7-8-9 mai 2014<br />\r\nmembre inferieur', 'Jean Pierre Barral, DO, MRO(F)', '', 'Florinda Czeija', '', '', 'florinda@czeija.at', 1),
(8, 'Scotland - Ecosse (Ayr)', 'Ayr', '', '26-27-28 septembre 2012<br />\r\n19-20-21 fevrier 2014<br />\r\n1-2-3 octobre 2014', 'Jean Pierre Barral, DO, MRO(F)', 'Barral Institute United Kingdom', 'Alison Harvey, DC', '26 Miller road<br />\r\nAyr, Scotland<br />\r\nKA7 2AY\r\n', '', 'www.barralinstitute.co.uk', 1),
(9, 'Spain - Espagne (Bilbao)', 'Bilbao', 'Visceral avancÃ©', '10-11-12 oct 2012\r\n', 'Jean Pierre Barral, DO, MRO(F)', '', 'International institute of advanced studies in osteopathy', 'Rambla sant just<br />\r\n6 local 1<br />\r\n08960 sant just desvern (Barcelona)<br />\r\nSpain', '+34-93-480-25-15', 'www.advancedosteopathy.com', 1),
(10, 'Spain - Espagne (Barcelona)', 'Barcelona', 'Colonne-bassin', '17-18-19 avril 2013', 'Jean Pierre Barral, DO, MRO(F)', '', 'International Institute of Advanced Studies in Osteopathy', 'Rambla sant just<br />\r\n6 local 1<br />\r\n08960 sant just desvern (Barcelona)<br />\r\nSpain', '+34-93-480-25-15', 'www.advancedosteopathy.com', 1),
(11, 'Spain - Espagne (Barcelona)', 'Barcelona', '', '20-21-22 nov 2013', 'Jean Pierre Barral, DO, MRO(F)', '', 'Javier Fernandez Gutierrez', '', '', 'jfguti@hotmail.com', 1),
(12, 'France (Lognes)', 'Lognes', '', '6-7-8 fevrier 2013<br />\r\n10-11-12 decembre 2014', 'Jean Pierre Barral, DO, MRO(F)', '', 'CETOHM PARIS', '10 rue Maison Rouge<br />\r\n77185 Lognes, France', '+33-1-60-37-61-60', '', 1),
(13, 'France (Mulhouse)', 'Mulhouse', 'Nouvelle approche manipulative de la colonne vertÃ©brale', '5-6-7 decembre 2012 ', 'Jean Pierre Barral, DO, MRO(F)', '', '', '', '', '', 1),
(14, 'France (Loos)', 'Loos', '', '5-6-7 mars 2014', 'Jean Pierre Barral, DO, MRO(F)', 'Lille OstÃ©opathie Post-Graduate(LOPG)', 'Jean-Marc Morel', '57 rue Salvador Allende<br />\r\n59120 Loos, France', '', 'ostÃ©o@post-graduate.fr', 1),
(15, 'France (Lille)', 'Lille', 'Colonne-bassin', '24-25-26 avril 2013', 'Jean Pierre Barral, DO, MRO(F)', '', 'Franck Dhennin', '', '', 'dhennin.melanie@orange.fr', 1),
(16, 'France ', 'Biarritz', '', '10-11-12 septembre 2014', 'Jean Pierre Barral, DO, MRO(F)', '', 'SOORF (Sud Ouest Osteopathy Recherche et Formation)', '', '', '', 1),
(17, 'England (London)', 'London', '', '25-26-27 avril 2012<br />\r\n7-8-9 novembre 2012<br />\r\n13-14-15 fevrier 2013<br />\r\n4-5-6 septembre 2013<br />\r\n9-10-11 avril 2014<br />\r\n12-13-14 novembre 2014', 'Jean Pierre Barral, DO, MRO(F)', 'CPDO', 'Eyal Lederman ', '', '', 'cpd@cpdo.net', 1),
(18, 'Italy - Italie (Rome & Bologne)', 'Rome & Bologne', '', 'Bologne: 21-22-23 juin 2012<br />\r\nRome: 22-23-24 mai 2013<br />\r\nRome: 4-5-6 decembre 2013<br />\r\nRome: 22-23-24 janvier 2014<br />\r\nRome: 4-5-6 juin 2014', 'Jean Pierre Barral, DO, MRO(F)', 'ESOMM', '', 'Viale Africa,108\r\n00144 Rome, Italy\r\n\r\n', '0957223767', 'info@esomm.com', 1),
(19, 'Italy - Italie (Naples)', 'Naples', '', '11-12-13 dec 2013', 'Jean Pierre Barral, DO, MRO(F)', 'AEMO', 'Nunzia Morelli', '', '', 'nunzia.morelli@libero.it', 1),
(20, 'Germany - Allemagne (Munich)', 'Munich', '', '19-20-21 septembre 2012<br />\r\n7-8-9 janvier 2013<br />\r\n13-14-15 mars 2013<br />\r\n6-7-8 janvier 2014\r\n', 'Jean Pierre Barral, DO, MRO(F)', '', 'MUNCHNERGRUPPE', 'koniginstr. 35A<br />\r\n80539 Munchen, Germany\r\n', '+49-89-26-62-09', 'info@muenchnergruppe.de', 1),
(21, 'France (Cailar)', 'Cailar', '', '6-7-8 septembre 2012<br />\r\n26-27-28 juin 2014', 'Jean Pierre Barral, DO, MRO(F)', '', 'MUNCHNERGRUPPE', 'koniginstr. 35A<br />\r\n80539 Munchen, Germany', '+49-89-26-62-09', 'info@muenchnergruppe.de', 1),
(22, 'Germany - Allemagne (Rohrdorf)', 'Rohrdorf', '', '7-8-9 fevrier 2014', 'Jean Pierre Barral, DO, MRO(F)', '', 'DOK', 'Anzengruberstr. 12<br />\r\n83101 Rohrdorf, Germany', '', 'Info@osteopathie-kolleg.com ', 1),
(23, 'Germany - Allemagne (Hamburg)', 'Hamburg', '', '19-20 nov 2012<br /><br />\r\n21-22-23 nov 2012:<br /> \r\nnouvelle approche manipulative du membre superieur<br /><br />\r\n3-4-5 avril 2013<br /><br />\r\n23-24-25 oct 2013<br /><br />\r\n27-28-29 mars 2014<br /><br />\r\n29-30-31 octobre 2014', 'Jean Pierre Barral, DO, MRO(F)', '', 'Osteopathie Schule Deutschland', 'Mexikoring 19<br />\r\nD-22297 Hamburg, Germany', '+49-644-15-69-0', 'osd@osteopathie-schule.de', 1),
(24, 'Holland - Hollande', '', '', '21-22-23 janv 2013', 'Jean Pierre Barral, DO, MRO(F)', '', 'Panta Rhei, RenÃ© Zweedijk', '', '', 'rzweedijk@zeelandnet.nl', 1),
(25, 'Latvia - Lettonie', '', '', '4-5-6-7 mars 2013<br />\r\n22-23-24-25 avril 2014', 'Jean Pierre Barral, DO, MRO(F)', '', '', '', '', '', 1),
(26, 'Japan -  Japon', '', '', '3-4-5-6 mai 2013', 'Jean Pierre Barral, DO, MRO(F)', '', '', '', '', '', 1),
(27, 'Canada (Montreal)', 'Montreal', '', '30-31 mai, 1-2-3-4 juin 2013', 'Jean Pierre Barral, DO, MRO(F)', '', '', '', '', '', 1),
(28, 'Russia - Russie', '', '', '3-4-5-6 novembre 2013<br />\r\n26-27-28-29 novembre 2014', 'Jean Pierre Barral, DO, MRO(F)', '', '', '', '', '', 1),
(29, 'USA', '', '', '15-16-17-18 mars 2014', 'Jean Pierre Barral, DO, MRO(F)', '', 'American Academy', '', '', '', 1),
(30, 'Norway - Norvege', '', '', '21-22-23 mai 2014', 'Jean Pierre Barral, DO, MRO(F)', '', '', '', '', '', 1),
(31, 'Japan -  Japon (Kobe)', 'Kobe', 'Advanced Visceral Manipulation', '11th, 12th, 13th August 2012 ', 'Marc Naudin, DO', '', '', '', '', '', 1),
(32, 'Germany - Allemagne (Bad Kissingen)', 'Bad Kissingen', 'Manipulation of the Cranial Nerves', '17th, 18th October 2014 ', 'Marc Naudin, DO', '', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `useridentities`
--

CREATE TABLE `useridentities` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `useridentities`
--

INSERT INTO `useridentities` (`id`, `username`, `password`) VALUES
(1, 'botoadmin', 'camelback');
